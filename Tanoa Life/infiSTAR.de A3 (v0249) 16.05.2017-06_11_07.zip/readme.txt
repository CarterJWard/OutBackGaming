/*
	Author: Chris(tian) "infiSTAR" Lorenzen
	Contact: infiSTAR23@gmail.com
	#e8dbd04db812
	
	colishere@gmail.com
	
	You should be able to download the latest update(s) on http://update.infistar.de/
	If you are a new customer, it might take a day or two until you are added to my database.
	Do not ask me how to get a key, read on that page and you will know.
	However, updates and support are not part of the purchase!
*/
/* *******************Developer : infiSTAR (infiSTAR23@gmail.com)******************* */
/* **************infiSTAR Copyright�� 2011 - 2016 All rights reserved.************** */
/* *********************************www.infiSTAR.de********************************* */
_______________________________________________________________________________________
It is very important that you read through the "infiSTAR_config.sqf".
Most people want to run this on AltisLife and forget to change the settings for AltisLife in the "infiSTAR_config.sqf".

Most checks should be set to true instead of false (in the infiSTAR_config.sqf) these are just diabled because
most users did not read the infiSTAR_config.sqf and then came to be aka "My ATM Menu is closing infiSTAR is broken"
and I had to copy paste what I have written in the infiSTAR_config.sqf EVERYTIME.

So please take your time and READ THAT FILE.

If you encounter problems, look into the infiSTAR Logs (written by the infiSTAR DLL FILES) and the server RPT log.
You may want to remove my UID from the _devs array.
Make sure to disabled and/or remove the mods default antihack if you AltisLife / Wasteland or Epoch
_______________________________________________________________________________________
IMPORTANT - DLLs:
===================
The .dll files are not essential and not part of the purchase.

You probably NEED "Visual C++ Redistributable Packages for Visual Studio 2013 - 32 Bit version"

armalog.dll
is creating (All Logs can be found in the server .rpt file as well, if you do not want to use this dll that is fine):
A3_HACKLOG_DATE.txt
A3_SURVEILLANCELOG_DATE.txt
+[...]
_______________________________________________________________________________________
Installation-Guide (How to install):
=========================================================
SERVER:
01. Open the .zip file you have gotten from the store and go to "infiSTAR.de_A3\SERVER_ARMA3_FOLDER\@infiSTAR_A3\addons\a3_infiSTAR"
02. Open the "infiSTAR_config.sqf" and add your AdminUID(s), then check if the different settings are fine for you :) - do not edit the other files.
	It is the most important thing that you read carefully through the "infiSTAR_config.sqf" and set all settings correctly for your server.
	You need to set the serverCommandPassword to the serverCommandPassword you have in your servers Config.cfg
	if there is no serverCommandPassword in your Config.cfg yet, set it like:
	serverCommandPassword = "passwordhere";

03. Go one folder back to "infiSTAR.de_A3\SERVER_ARMA3_FOLDER\@infiSTAR_A3\addons" and make the folder "a3_infiSTAR" to a pbo ("a3_infiSTAR.pbo")
04. Now Move the "@infiSTAR_A3" folder on your gameserver into your "Arma3Server" folder.
05. Now go back to your "infiSTAR.de_A3\SERVER_ARMA3_FOLDER" folder (in the unpacked zip you got from me) and move the dll files you can find there into your Servers Arma3 main folder.

06. The HPP "infiSTAR_AdminMenu.hpp" and "call.fsm" you got in the zip from me "infiSTAR.de_A3\MPMission" need to be copied into your mpmission "Arma3Server\MPMissions\missionname"
07. Open the description.ext in your MPmission to add the following:
	#include "infiSTAR_AdminMenu.hpp"

08. Copy the BattleyeFilters from "infiSTAR.de_A3\YOURMOD_BattleEye_Filters" over into your Battleye folder on the Server. Be sure to copy them into the correct folder.
	If there is no fitting filters for your mod, you will have to make the mods default filters working along with infiSTAR yourself.
	I am not affiliated with Battleye in any way. Guides & help regarding BE Filters can be found here:
		Battleye Filter TXT GUIDE:
		http://www.exilemod.com/topic/74-how-to-battleye-filters-do-it-yourself/?do=findComment&comment=1077
		or https://pastebin.com/9FBdjS1u if forum thread is gone
		
		Battleye Filter Tools:
		1. BattlEye Filters are time consuming and are different if you are running a modifed version.
			Check out http://www.exilemod.com/topic/9708-battleye-filter-editor/
		2. http://bfe.marma.io/
	
09. That is it, very easy and fast done - Start up your server! :) - Default Open Menu Key is F1


Running AltisLife?
You have to to remove 

CONST(W_O_O_K_I_E_ANTI_ANTI_HAX,"false");
CONST(W_O_O_K_I_E_FUD_ANTI_ANTI_HAX,"false");
CONST(E_X_T_A_S_Y_ANTI_ANTI_HAX,"false");
CONST(E_X_T_A_S_Y_Pro_RE,"false");
CONST(E_X_T_A_S_Y_Car_RE,"false");
CONST(DO_NUKE,"false");
CONST(JxMxE_spunkveh,"false");
CONST(JxMxE_spunkveh2,"false");
CONST(JxMxE_spunkair,"false");
CONST(JJJJ_MMMM___EEEEEEE_LLYYSSTTIICCC_SHIT_RE,"false");
CONST(JJJJ_MMMM___EEEEEEE_LLYYSSTTIICCC_SHIT_RE_OLD,"false");
CONST(JJJJ_MMMM___EEEEEEE_SPAWN_VEH,"false");
CONST(JJJJ_MMMM___EEEEEEE_SPAWN_WEAPON,"false");

and these 3 lines
[] execVM "SpyGlass\fn_cmdMenuCheck.sqf";
[] execVM "SpyGlass\fn_variableCheck.sqf";
[] execVM "SpyGlass\fn_menuCheck.sqf";
from your
Arma3server\MPMissions\Altis_Life.Altis\SpyGlass\fn_initSpy.sqf
file.

In theory you could (and maybe should) completely remove spyglass, but it works just fine if those checks are removed.
infiSTAR does similar things anyways!








Running Arma 3 Epoch?
Need more help because above did not work out for you?
Here another try:
	01. Open the .zip file you have gotten from the store and go into the subfolder "SERVER_ARMA3_FOLDER"
	02. Copy & Paste the folder "@infiSTAR_A3" (and all the DLL files) into your Arma3 server folder (not in any sub folder of the Arma3 server folder)
	03. Go into "SERVER_ARMA3_FOLDER\@infiSTAR_A3\addons\a3_infiSTAR" and modify the "infiSTAR_config.sqf" to your needs.
	04. Once you are done, make a PBO file out of the "a3_infiSTAR" folder (You can use PBO Manager or similar tools) and remove the Folder after doing that (so only the pbo is left here: "@infiSTAR_A3\addons")
	05. Modify your start .bat file or server init line so it has this "-servermod=@infiSTAR_A3;"
		Example from my test-server:
		-enableHT -autoinit "-servermod=@EpochHive;@infiSTAR_A3" "-mod=@Epoch"
	06. Open the "infiSTAR_config.sqf" and add your AdminUID(s), then check if the different settings are fine for you :) - do not edit the other files.
		It is the most important thing that you read carefully through the "infiSTAR_config.sqf" and set all settings correctly for your server.
	07. Go into "@epochhive" and open "epochah.hpp"
	08. Make sure to have these settings:
		antihack_Enabled = false;
		antihack_cfgPatchesCheck = false;
	09. MPMission - the hpp file (infiSTAR_AdminMenu):
		To use the infiSTAR_AdminMenu Dialog you will need to edit your current MPMission.
		Go into your servers MPMissions folder and unpack the mission pbo file you want to run.
		Now open the "description.ext" and add (just at the very bottom should work fine) this:
		#include "infiSTAR_AdminMenu.hpp"
		Now you need to copy the "infiSTAR_AdminMenu.hpp" (and the "call.fsm") from "MPMission Addition(s)" into the MPMission (so it is right next to your "description.ext").
		Repack the mission to a pbo again.
		You have to do this, or you will not be able to open the AdminMenu..!
	10. Default Open Menu Key is F1





Good to know - Keybinds:
1. You can spectate by double clicking the name of a player in the admin menu.
2. Keybinds:
	F1 - Default AdminMenu Key
	F2 & SHIFT - Adminconsole
	F6 - Heal Yourself
	F7 - Heal & Repair withing 15m
	F8 - Flip CursorTarget Vehicle
	F9 - Show Gear of Player you are currently spectating (might close if player moves)
	F9 & SHIFT- To hide/show specate overlay (while spectating)
	F10 - Stop Spectating
	F11 - Add Ammo for current weapon
	4 & SHIFT - Fly Up
	4 & CTRL - Teleport Up
	5 - Teleport in looking direction
	6 - Eject CursorTarget
	7 - Unlock/Lock targeted Vehicle
	7 - Opens/Closes targeted Door/Hatch/Gate
	8 - Upgrade building (Epoch).
	TAB & SHIFT - Open Map
	I & SHIFT - Show Info about CursorTarget
	DELETE - Delete CursorTarget

3. If the map is opened and you hold LEFT-ALT key, you can click on the map and teleport there!
4. If you are added in the run.sqf as an admin, you are able to change from admin to a normal player and back by typing !admin in the chat.
_______________________________________________
You have problem?
send me the following:
	- server rpt file (complete file, not just a part of it - VERY IMPORTANT!)
	- client rpt file from you when you were trying to connect to the server, while it had the error
	- infiSTAR Log files (if it already wrote logs)
	- your current mpmission file
	- gameserver provider (if it is not your own dedi box - if it is your box, tell me)
	- purchase email (used in payment process)
	- update.infiSTAR.de used steam id
	- server name
	- server mod + version
	- custom scripts that could cause trouble
	- custom mods that could cause trouble
make sure to use the latest infiSTAR version!
_______________________________________________
infiSTAR.de is used and supported by the biggest and best Communities like:

I am doing this as a passionate 1-man Project.
The tool is actively developed and updated, trying to get the best
results vs Scripters, Hackers while implementing helpful features to administrate your server(s).

I ty to help anyone who needs help but it is very easy structured and self-explaining.
The tool comes with a readme including install instructions and there is even pictures.

If you have seen my tool on another server and you are not convinced about purchasing it yourself or what it does, how it works  or just unsure if you want to purchase it for your server/community.
I can offer you to add your UID to a Test-server so you can at least get a feel of a few benefits you get.

Due to the nature of this software, it needs to be updated quite often, because of new mods, mod updates or new hacks.
I provide Updates and support for my customers for more than 2 years now.
I am happy to go on providing Updates as long as it is possible for me.

Thanks for your attention.

P.S.
Thanks to those, who help(ed) me testing new features, bugs or sending in Hacks to check against them :)
__________________________________________________
You(I) hereby agree to the following

TERMS AND CONDITIONS
The script (which is a plain written text) stays property of infiSTAR.
As author he is the only one allowed to modify, share (sell, post, [..]) it.
You are not allowed to copy/modify any kind of intellectual property of infiSTAR (this),
unless you are permitted by infiSTAR.
This is a one time payment for the product in its present state.
Commercial use is prohibited unless it is permitted by infiSTAR.

REFUND POLICY
You agree that infiSTAR offers no refunds and all payments are final. 
Furthermore, you shall not institute any form or charge-back for any fees paid to infiSTAR. 
You acknowledge that you have read and agree to the above Policy.


Urheber- und Leistungsschutzrechte
Die infiSTAR Dateien und ihr Inhalt unterliegen dem deutschen Urheber- und Leistungsschutzrecht.
Die unerlaubte Vervielf�ltigung oder Weitergabe einzelner Inhalte oder kompletter Dateien ist nicht gestattet und strafbar.
Dies ist eine einmalige Zahlung f�r das Produkt im Gegenw�rtigen Zustand zum Zeitpunkt des Verkaufs.
Es ist ausschlie�lich der private und nicht kommerziellen Gebrauch erlaubt.
� 11 UrhG
Das Urheberrecht sch�tzt den Urheber in seinen geistigen und pers�nlichen Beziehungen zum Werk und in der Nutzung des Werkes.
Es dient zugleich der Sicherung einer angemessenen Verg�tung f�r die Nutzung des Werkes.
� 97 UrhG
Anspruch auf Unterlassung und Schadensersatz
� 98 UrhG
Anspruch auf Vernichtung, R�ckruf und �berlassung
� 106 UrhG
Unerlaubte Verwertung urheberrechtlich gesch�tzter Werke
(1) Wer in anderen als den gesetzlich zugelassenen F�llen ohne Einwilligung des Berechtigten ein Werk oder eine Bearbeitung oder Umgestaltung eines Werkes vervielf�ltigt, verbreitet oder �ffentlich wiedergibt, wird mit Freiheitsstrafe bis zu drei Jahren oder mit Geldstrafe bestraft.
(2) Der Versuch ist strafbar.
/* *******************Developer : infiSTAR (infiSTAR23@gmail.com)******************* */
/* **************infiSTAR Copyright�� 2011 - 2016 All rights reserved.************** */
/* *********************************www.infiSTAR.de********************************* */