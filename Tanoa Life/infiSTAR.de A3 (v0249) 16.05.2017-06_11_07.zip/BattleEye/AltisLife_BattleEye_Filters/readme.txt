These filters are a WIP and are only applicable to the most update to date vanilla Altis Life RPG. Any modifications to Altis Life will require you
to test the Battleye filters first!

As said some of these filters are WIP as others are tested. A few of which cause concern.